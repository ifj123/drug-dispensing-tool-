<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "media_library";

// Create a connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database
$sql = "CREATE DATABASE IF NOT EXISTS $database";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully<br>";
} else {
    echo "Error creating database: " . $conn->error . "<br>";
}


$conn->select_db($database);


$sql = "CREATE TABLE IF NOT EXISTS books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    img VARCHAR(255) NOT NULL,
    genre VARCHAR(50),
    format VARCHAR(50),
    year INT,
    authors VARCHAR(255),
    publisher VARCHAR(100),
    isbn VARCHAR(20)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'books' created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}


$sql = "CREATE TABLE IF NOT EXISTS movies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    img VARCHAR(255) NOT NULL,
    genre VARCHAR(50),
    format VARCHAR(50),
    year INT,
    director VARCHAR(100),
    writers VARCHAR(255),
    stars VARCHAR(255)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'movies' created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

// SQL query to create a table for music
$sql = "CREATE TABLE IF NOT EXISTS music (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    img VARCHAR(255) NOT NULL,
    genre VARCHAR(50),
    format VARCHAR(50),
    year INT,
    artist VARCHAR(100)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'music' created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

$catalog = [];  // Your media catalog data

foreach ($catalog as $id => $item) {
    if ($item['category'] === 'Books') {
        $sql = "INSERT INTO books (title, img, genre, format, year, authors, publisher, isbn)
                VALUES (
                    '{$item['title']}',
                    '{$item['img']}',
                    '{$item['genre']}',
                    '{$item['format']}',
                    '{$item['year']}',
                    '" . implode(', ', $item['authors']) . "',
                    '{$item['publisher']}',
                    '{$item['isbn']}'
                )";
    } elseif ($item['category'] === 'Movies') {
        $sql = "INSERT INTO movies (title, img, genre, format, year, director, writers, stars)
                VALUES (
                    '{$item['title']}',
                    '{$item['img']}',
                    '{$item['genre']}',
                    '{$item['format']}',
                    '{$item['year']}',
                    '{$item['director']}',
                    '" . implode(', ', $item['writers']) . "',
                    '" . implode(', ', $item['stars']) . "'
                )";
    } elseif ($item['category'] === 'Music') {
        $sql = "INSERT INTO music (title, img, genre, format, year, artist)
                VALUES (
                    '{$item['title']}',
                    '{$item['img']}',
                    '{$item['genre']}',
                    '{$item['format']}',
                    '{$item['year']}',
                    '{$item['artist']}'
                )";
    }

   
    if ($conn->query($sql) === TRUE) {
        echo "Record for '{$item['title']}' inserted successfully<br>";
    } else {
        echo "Error inserting record for '{$item['title']}': " . $conn->error . "<br>";
    }
}


$conn->close();
?>
